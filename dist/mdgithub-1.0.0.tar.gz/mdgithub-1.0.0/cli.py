import sys
from . import main

def cli():
    """CLI entry point."""
    sys.exit(main())

if __name__ == "__main__":
    cli()